let mi_arreglo = [1,2,3,4,5]
/* console.log(mi_arreglo)
console.log(mi_arreglo.length) */

/* for (var i = 0; i < mi_arreglo.length; i = i + 1){
    console.log(mi_arreglo[i])
}  */

let mi_arreglo_2 = [true, 4.5, 'Hola', 'Educa2' , 10]

for (var i = 0; i < mi_arreglo_2.length; i = i + 1){
    console.log(mi_arreglo_2[i])
} 