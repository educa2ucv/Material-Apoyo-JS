/*
    Funciones en JavaScript:

    function nombre_de_funcion (parametros){
        Bloque de código
    }
*/

function suma (a,b){
    console.log("El resultado de la suma es: " + (a+b))
}

suma(20,50)
suma(100,150)
