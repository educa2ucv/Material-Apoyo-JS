/* function suma (a,b){
    return a+b
} */

const suma = (a,b) => a+b
const multiplicacion = (a,b,c) => a*b*c

const imprimir_varios_mensajes = () => {
    console.log('Hola')
    console.log('Hola')
    console.log('Hola')
    console.log('Hola')
    console.log('Hola')
    console.log('Hola')
    console.log('Hola')
}

/* 
let resultado = suma(20,70)
let resultado2 = multiplicacion(10,20,35)
console.log(resultado,resultado2) */


imprimir_varios_mensajes()