function ejecutar (foo){
    foo()
}

/* function saludo (){
    console.log('Hola a todos')
} */

ejecutar(() => {
    console.log('Hola estoy programando en JS')
})

