class Usuario{
    
    saludo(){
        console.log('Hola')
    }

    static despedida(){
        console.log('Hasta luego')
    }
}

Usuario.despedida()